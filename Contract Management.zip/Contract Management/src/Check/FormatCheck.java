package Check;

public class FormatCheck {

	public boolean newCheck(String title,String client,String starttime,String endtime,String content) {
		return true;
	}
	
	public boolean allotCheck(String[] joinpeople,String[] approvepeople,String[] signpeople) {
		return true;
	}
	
	public boolean joinCheck(String joinopinion) {
		return true;
	}
	
	public boolean unfinishedCheck(String title,String client,String starttime,String endtime,String content) {
		return true;
	}
	
	public boolean approveCheck(String approveopinion) {
		return true;
	}
	
	public boolean signCheck(String signopinion) {
		return true;
	}
}
