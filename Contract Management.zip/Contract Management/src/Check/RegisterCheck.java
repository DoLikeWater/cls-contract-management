package Check;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;




public class RegisterCheck {

	
	//�ж�ע����Ϣ�Ƿ�Ϸ�������true,����false
		
		public   boolean isNumeric(String str){
			  for (int i = 0; i < str.length(); i++){
			   if (!Character.isDigit(str.charAt(i))){
			    return false;
			   }
			  }
			  return true;
		}

		public  boolean Registerjudege(String account,String name, String password,String number){
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://127.0.0.1:3306/contract?useUnicode=true&amp;" +
					"characterEncoding=utf8&useSSL=true";
			String user = "root";
			String password1 = "264737";
			
			if (name==null || name.length()<=0){
				return false;//����Ϊ��
				
			}
			else if(account==null || account.length()<6){
				return false;//�˺�̫��
			}
			else if(password==null || password.length()<6){
				return false;//����̫��
			}
			else if(number==null || isNumeric(number)==false || number.length()!=11){
				return false;//�ֻ��Ÿ�ʽ����ȷ
			}
			else{
				try {
					Class.forName(driver);

					Connection conn = DriverManager.getConnection(url, user, password1);
					Statement statement = conn.createStatement();
					String sql = "insert into userinfo(name,account,password,number) value(" + "\""+name + "\""+ ','+ "\""+account +"\""+',' + "\""+password +"\""+',' + number+ ")";
					statement.execute(sql); 
					
				}catch(ClassNotFoundException e) {    
					e.printStackTrace();   
					} catch(SQLException e) {   
					e.printStackTrace();   
					} catch(Exception e) {   
					e.printStackTrace();   
					}   
		}
			return true;//ע��ɹ�	
	}
		
		

}
